# pyinverted
A inverted files implementation in Python 3.
