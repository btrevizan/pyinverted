from .inverted import Inverted
